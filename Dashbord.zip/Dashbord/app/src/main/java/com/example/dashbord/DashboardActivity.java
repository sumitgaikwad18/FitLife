package com.example.dashbord;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    Button btnWorkout, btnRecovery, btnAnalytics, btnProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnWorkout = findViewById(R.id.btnWorkout);
        btnRecovery = findViewById(R.id.btnRecovery);
        btnAnalytics = findViewById(R.id.btnAnalytics);
        btnProfile = findViewById(R.id.btnProfile);

        btnWorkout.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this,WorkoutActivity.class))
        );

        btnRecovery.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, RecoveryActivity.class))
        );

        btnAnalytics.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, AnalyticsActivity.class))
        );

        btnProfile.setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, ProfileActivity.class))
        );
    }
}
